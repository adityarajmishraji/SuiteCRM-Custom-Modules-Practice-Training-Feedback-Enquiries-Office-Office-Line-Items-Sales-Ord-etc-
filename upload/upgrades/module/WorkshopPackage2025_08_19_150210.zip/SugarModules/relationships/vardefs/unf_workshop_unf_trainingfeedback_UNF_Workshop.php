<?php
// created: 2025-08-19 15:02:10
$dictionary["UNF_Workshop"]["fields"]["unf_workshop_unf_trainingfeedback"] = array (
  'name' => 'unf_workshop_unf_trainingfeedback',
  'type' => 'link',
  'relationship' => 'unf_workshop_unf_trainingfeedback',
  'source' => 'non-db',
  'module' => 'UNF_TrainingFeedback',
  'bean_name' => 'UNF_TrainingFeedback',
  'side' => 'right',
  'vname' => 'LBL_UNF_WORKSHOP_UNF_TRAININGFEEDBACK_FROM_UNF_TRAININGFEEDBACK_TITLE',
);
