<?php
$module_name='UNF_Office';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'UNF_Office',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'office_name' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_OFFICE_NAME',
      'width' => '10%',
      'default' => true,
    ),
    'phone_number' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PHONE_NUMBER',
      'width' => '10%',
      'default' => true,
    ),
    'address' => 
    array (
      'type' => 'text',
      'studio' => 'visible',
      'vname' => 'LBL_ADDRESS',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'description' => 
    array (
      'type' => 'text',
      'studio' => 'visible',
      'vname' => 'LBL_DESCRIPTION',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
    'date_modified' => 
    array (
      'vname' => 'LBL_DATE_MODIFIED',
      'width' => '45%',
      'default' => true,
    ),
    'assigned_user_name' => 
    array (
      'link' => true,
      'type' => 'relate',
      'vname' => 'LBL_ASSIGNED_TO_NAME',
      'id' => 'ASSIGNED_USER_ID',
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'Users',
      'target_record_key' => 'assigned_user_id',
    ),
    'created_by_name' => 
    array (
      'type' => 'relate',
      'link' => true,
      'vname' => 'LBL_CREATED',
      'id' => 'CREATED_BY',
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'Users',
      'target_record_key' => 'created_by',
    ),
    'date_entered' => 
    array (
      'type' => 'datetime',
      'vname' => 'LBL_DATE_ENTERED',
      'width' => '10%',
      'default' => true,
    ),
    'modified_by_name' => 
    array (
      'type' => 'relate',
      'link' => true,
      'vname' => 'LBL_MODIFIED_NAME',
      'id' => 'MODIFIED_USER_ID',
      'width' => '10%',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => 'Users',
      'target_record_key' => 'modified_user_id',
    ),
    'line_items' => 
    array (
      'type' => 'html',
      'studio' => 'visible',
      'vname' => 'LBL_LINE_ITEMS',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
  ),
);