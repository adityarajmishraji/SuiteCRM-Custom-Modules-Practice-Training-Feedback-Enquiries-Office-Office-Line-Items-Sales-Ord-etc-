<?php
 // created: 2025-08-26 16:39:53
$layout_defs["UNF_Office"]["subpanel_setup"]['unf_office_unf_office_line_items'] = array (
  'order' => 100,
  'module' => 'UNF_Office_Line_Items',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_UNF_OFFICE_UNF_OFFICE_LINE_ITEMS_FROM_UNF_OFFICE_LINE_ITEMS_TITLE',
  'get_subpanel_data' => 'unf_office_unf_office_line_items',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
