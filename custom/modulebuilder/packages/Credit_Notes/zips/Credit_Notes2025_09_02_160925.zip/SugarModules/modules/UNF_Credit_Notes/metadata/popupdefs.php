<?php
$popupMeta = array (
    'moduleMain' => 'UNF_Credit_Notes',
    'varName' => 'UNF_Credit_Notes',
    'orderBy' => 'unf_credit_notes.name',
    'whereClauses' => array (
  'name' => 'unf_credit_notes.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
    'name' => 'name',
  ),
),
);
