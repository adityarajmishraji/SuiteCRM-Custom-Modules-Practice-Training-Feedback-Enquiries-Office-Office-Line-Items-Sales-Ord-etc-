<?php
// created: 2025-09-03 17:21:27
$dictionary["UNF_Chalan"]["fields"]["unf_chalan_unf_chalan_line_items"] = array (
  'name' => 'unf_chalan_unf_chalan_line_items',
  'type' => 'link',
  'relationship' => 'unf_chalan_unf_chalan_line_items',
  'source' => 'non-db',
  'module' => 'UNF_Chalan_Line_Items',
  'bean_name' => 'UNF_Chalan_Line_Items',
  'side' => 'right',
  'vname' => 'LBL_UNF_CHALAN_UNF_CHALAN_LINE_ITEMS_FROM_UNF_CHALAN_LINE_ITEMS_TITLE',
);
